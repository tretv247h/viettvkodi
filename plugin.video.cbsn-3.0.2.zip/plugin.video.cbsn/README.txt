plugin.video.cbsn
================

Kodi Video Addon for CBS News Live
For Kodi Isengard and above releases

Version 3.0.2 website change
Version 3.0.1 separate scraper for future ftunctions
Version 2.0.4 website change (live url)
Version 2.0.3 website change (live url)
Version 2.0.2 cleanup for release
Version 2.0.1 initial release

